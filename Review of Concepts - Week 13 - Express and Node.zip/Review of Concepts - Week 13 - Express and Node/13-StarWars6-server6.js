// NOTE: times from videos are from video https://www.youtube.com/watch?v=L72fhGm1tfE unless otherwise specified

// Dependencies
// =============================================================
var express = require("express");
var path = require("path");


// Sets up the Express App (REVIEW OF CONCEPTS: Intiates express)
// =============================================================
var app = express();
var PORT = process.env.PORT || 3000;

// Sets up the Express app to handle data parsing (interpretation/body parser)
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
// REVIEW OF CONCEPTS:
// 1. Sets up middleware for express; app.use(); will run middleware on all requests as defined in app.get("/route", ... https://www.youtube.com/watch?v=9HOem0amlyg
// 2. app.use(express.json()); handles raw JSON whereas app.use(express.urlencoded({ extended: true })); handles forms submissions & urlencoded data (44:08)
// 3. Middleware functions a) are functions that have access to the request & response object. Express has built-in middleware but middleware also may come from 3rd party packages; b) execute any code; c) make changes to request/response objects; d) end response cycle; e) call next middleware in the stack by calling next(); f) are a stack of functions that executes whenever a request is made to the server https://www.youtube.com/watch?v=L72fhGm1tfE
// 4. Middleware: any number of functions that are invoked by the Express.js routing layer before your final request handler is made: https://www.youtube.com/watch?v=9HOem0amlyg. So on the defined route/endpoint, do something FIRST & then pass it along to the next(): 
// app.get("/route", function(req, res, next) {
// Do something
// next();
// }, function(req, res){
// Do something else
// }
// });
// e.g., of middleware for app.post:
// app.post(/upload, auth.isAuthenticated(), controller.upload); where auth.isAuthenticated(), controller.upload are middleware functions that occur before user is sent to final route /upload; auth.isAuthenticated() will call next() to run controller.upload but controller.upload will NOT call next() because it's the last function in the chain https://www.youtube.com/watch?v=9HOem0amlyg
// 5. var PORT = process.env.PORT || 3000, where process.env.PORT is for Heroku deployment

// Star Wars Characters (DATA)
// =============================================================
var characters = [
  {
    routeName: "yoda",
    name: "Yoda",
    role: "Jedi Master",
    age: 900,
    forcePoints: 2000,
  },
  {
    routeName: "darthmaul",
    name: "Darth Maul",
    role: "Sith Lord",
    age: 200,
    forcePoints: 1200
  },
  {
    routeName: "obiwankenobi",
    name: "Obi Wan Kenobi",
    role: "Jedi Master",
    age: 55,
    forcePoints: 1350
  }
];

// Routes
// REVIEW OF CONCEPTS: Create your endpoints & route handlers
// =============================================================
// Basic route that sends the user first to the AJAX Page
app.get("/", function(req, res) {
  res.sendFile(path.join(__dirname, "view.html"));
});
// REVIEW OF CONCEPTS: 
// The path module provides utilities for working with file and directory paths. It can be accessed using: var path = require('path');
// path.join() method joins all given path segments together using the platform-specific separator as a delimiter, then normalizes the resulting path. Example: path.join('/foo', 'bar', 'baz/asdf', 'quux', '..');
// Returns: '/foo/bar/baz/asdf'
// all routes don't need to be APIs where you're using serving JSON. You may use routes that serve server-side templates (38:00). When sending data to a web server, the data has to be a string. (e.g., convert a JavaScript object into a string with JSON.stringify()). 
// .get method is a method from express
// "/" is route; 2nd parameter is function(req,res){}
// response object has method .send and .sendFile that it will send to the BROWSER
// __dirname gives you the current directory (directory you are on), while .join combines the two words: __dirnameview.html, where view.html is the file to be loaded (17:25).
// using "/" route is not ideal as you would need to manually enter endpoints (better suited for static servers) (21:20)
// everytime a change is made must restart server (CTRL+C) or install nodemon which restarts/reload/reset server everytime there is a change. Run nodemon on terminal along with filename vs node to test your code
// better suited for static servers where you enter routes manually (e.g., about page)

// Displays all characters
app.get("/api/characters", function(req, res) {
  return res.json(characters);
});
// REVIEW OF CONCEPTS: 
// "/api/characters" is route; function(req,res){} is the 2nd parameter & callback function
// res.json to get characters array to show up on browser in json
// res.json([body]): Sends a JSON response. This method sends a response (with the correct content-type) that is the parameter converted to a JSON string using JSON.stringify().Parameter can be any JSON type, including object, array, string, Boolean, number, or null, and you can also use it to convert other values to JSON. https://expressjs.com/en/api.html#res.json


// Displays a single character, or returns false
app.get("/api/characters/:character", function(req, res) {
  var chosen = req.params.character;

  console.log(chosen);

  for (var i = 0; i < characters.length; i++) {
    if (chosen === characters[i].routeName) {
      return res.json(characters[i]);
    }
  }

  return res.json(false);
});

// REVIEW OF CONCEPTS:
// 1.  "/api/characters/:character" is route
// 2. :character is a url parameter; use request object to grab whatever is in url parameter :character: var chosen = req.params.character;
// (31:40); when you type in app.get("/api/characters/:character") into the url, DO NOT include colon. Instead type in : localhost:3000/api/characters/character. essentially, you can make :character say :4 or :meow as it is just the endpoint or final route; (32:30)
// 3. var chosen = req.params.character is a string: so if you're filtering an array for a number === req.params.character, you must use parseInt(req.params.character); (34:00)
// 4. Basic Route Handling: app.get (going to a webpage), app.post
// 5. send file: similar to fs.Read file but less cumbersome: 


// 1. can inspect network at same time while testing this (Google inspect); select Network, XHR
// 2. In express, [:] means this is the parameter that I want to set up in express; example: /:character/:place: is what you type in the URL (which represents the routeName which is case-specific)
// 3. req.params: allows you to extract argument that you pass in
// 4. We will use RAILS (more opinionated than express). MODEL VIEW CONTROLLER (MVC) will be our model controller; VIEWs: what is displayed to screen
// 5. EXAMPLE of building an external API: as soon as you hit the route/endpoint, the callback functions execute; able to query to get to specific data you want


// Create New Characters - takes in JSON input
app.post("/api/characters", function(req, res) {
  // req.body hosts is equal to the JSON post sent from the user
  // This works because of our body parsing middleware
  // ROC: middleware allows us to store this information posted in req.body
  // use Postman to send POST request: MyWorkspace->POST->body->raw->http://localhost:8080, SEND
  var newcharacter = req.body;

  // can account for not entering a new character:
  // if(!req.body.routeName || !req.body.name || !req.body.role || !req.body.age || !forcePoints) {return res.status(400).json({msg: "Please include a routeName, name, role, age, and forcePoints."})}

  console.log(newcharacter);

  // We then add the json the user sent to the character array
  characters.push(newcharacter);

  // We then display the JSON to the users 
  res.json(newcharacter);
  // res.json(characters) if you want to send the update array of characters (with newcharacter)back to the user
  // res.send(req.body) would send the JSON object we entered (req.body) to the second content box in Postman under body -> pretty (44:40)
});

// REVIEW OF CONCEPTS 
// 1. When creating something on the server or adding to a database, use .post() request in most cases, (41:28)
// 1. POSTMAN: use Postman (http client) to make requests to the server. Select body->JSON as our middleware requires us to post JSON. If you don't specify the routeName as part of the object, you will see false because that is part of the specifications of the for loop
// 2. POST vs GET: different types of http methods. Can use same routes as long as you use different methods. When sending post via Postman, ensure you're sending JSON data so select 1) post; 2) url with local host: http:localhost:PORT/route; 3) headers: {content-type: application/json}; 4) body: raw AND type in the JSON object (double quotation marks around key & value) you want to add in the content box === req.body; to access value within req.body, use req.body.key (46:23); 5) you will see the response in the content box at the bottom of the page under body -> pretty (41:50).  
// 3. hard to post using browser so we use Postman to make API requests (allows us to see response), allowing us to see response from endpoints; Postman is a great testing tool
// res.json(newcharacter); DON'T have to use JSON.stringify() method, which converts a JavaScript object or value to a JSON string, because res.json takes care of this, converting a JSON object into a JSON string. When sending data to a web server, the data has to be a string. (e.g., convert a JavaScript object into a string with JSON.stringify()). 
// var obj = { name: "John", age: 30, city: "New York" };
// var myJSON = JSON.stringify(obj);
// RETURNS:
// {"name":"John","age":30,"city":"New York"}



// Starts the server to begin listening

// =============================================================
app.listen(PORT, function() {
  console.log("App listening on PORT " + PORT);
});

// REVIEW OF CONCEPTS:
// 1. listen() is a built-in method in express; need to listen on a port to run web server https://www.youtube.com/watch?v=L72fhGm1tfE
// 2. passing in PORT and call-back function

// installing POSTMAN: run on terminal: npm init -y (-y so you don't have to enter yes to all questions) to create package.json file with dependencies

// TESTING CODE ABOVE
// 1. Code is similar to acitivies 11-12 with the exception of 

// 1. Since express is already listed as dependencies in package.json, run npm install express. Path is an internal module of Node.js - not a npm package.
// 2. Ensure you are in the root directory of app you are testing.
// 3. In terminal/node/bash, ENTER: nodemon server6.js
// RETURNS: 
