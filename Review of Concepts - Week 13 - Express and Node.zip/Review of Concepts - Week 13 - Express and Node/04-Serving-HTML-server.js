// Dependencies
var http = require("http");
var fs = require("fs");
// REVIEW OF CONCEPTS:
// 1. http and fs are core modules of Node.js so don't have to run separate npm packages


// Set our port to 8080
var PORT = 8080;

// Create our server
var server = http.createServer(handleRequest);

// Create a function for handling the requests and responses coming into our server
function handleRequest(req, res) {

  // Here we use the fs package to read our index.html file
  fs.readFile(__dirname + "/index.html", function(err, data) {

    // We then respond to the client with the HTML page by specifically telling the browser that we are delivering an html file.
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(data);
  });
}

// REVIEW OF CONCEPTS
// Dissecting function handleRequest(req, res) {}: // request is sent in request Object; response is sent in response object
// return fs.readFile(__dirname + "/index.html", function(err, data): {callback function function(err, data) (after readFile index.html), where data represents data read from file index.html; index.html is in same root directory as server.js
  // res.writeHead(200, { "Content-Type": "text/html" }); : Configure the response to return a status code of 200 (meaning everything went OK), and to be an HTML document; see activity03-Portfolio on how to use Google Inspect Tools to see Header details
  // res.end(data): End the response by sending the client the data, which gets rendered as the index.html document:

// Starts our server
server.listen(PORT, function() {
  console.log("Server is listening on PORT: " + PORT);
});

// REVIEW OF CONCEPTS
// TEST CODE ABOVE (ensure in same directory as server.js and have terminated prior port from listening for client requests (CTRL+C)
// 1. enter the following in terminal: node server.js
// 2. RETURNS ON CONSOLE/TERMINAL/BASH: Server is listening on PORT: 8080 (server must be listening before it can process a client request)
// 3. then enter the following into address/URL bar: http://localhost:8080/index.html
// 4. renders/displays the following on the webpage (index.html file): 
// My Favorite Things
// Here are some of my favorite things!
// Coding
// JavaScript
// HTML
// CSS
// 5. See Activity03-Portfolio to see details on headers (status, content-type)
// 6. Terminate port from listening for client requests (CTRL+C)