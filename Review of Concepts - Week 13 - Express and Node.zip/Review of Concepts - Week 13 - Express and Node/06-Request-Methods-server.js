// REVIEW OF CONCEPTS REFERENCES:
// https://nodejs.org/es/docs/guides/anatomy-of-an-http-transaction/

// Dependencies
var http = require("http");

var PORT = 8080;

var server = http.createServer(handleRequest);

// REVIEW OF CONCEPTS:  
// 1. http module in Node.js (don't have to install) can create a web server that listens on a given PORT to create a back-end service for client applications; http.createServer()function is defined in http module. "http module" is internal to node so DO NOT have to install it. Node.js's HTTP API is very low-level, dealing only with steream handling & message parsing (parsing a message into headers & body (H&B) without parsing H&B)
// 2. Any node web server application will at some point have to create a web server object. This is done by using createServer, where var server is the web server object AND an EventEmitter.// https://nodejs.org/es/docs/guides/anatomy-of-an-http-transaction/
// 3. All objects which emit events are the instances of events.EventEmitter.
// https://www.tutorialspoint.com/nodejs/nodejs_event_emitter.htm
// 4. The function that's passed in to createServer (handleRequest) is called once for every HTTP request that's made against that server, so it's called the request handler. // https://nodejs.org/es/docs/guides/anatomy-of-an-http-transaction/


function handleRequest(req, res) {

  // Saving the request data as a variable
  var requestData = "";

  req.on("data", function(data) {

    // Add it to requestData.
    requestData += data;
  });

  // When the request has ended...
  req.on("end", function() {

    // Log (server-side) the request method, as well as the data received!
   
    console.log("You did a", req.method, "with the data:\n", requestData);
    res.end();
    // REVIEW OF CONCEPTS: 
    // 1. req.method in Postman (e.g., POST, GET)
    // 2. requestData: What user enters into Body for Request
  });
}

// When the server receives data...
  // REVIEW OF CONCEPTS:
  // 1. Before listening, we must REGISTER a listener or handler for an event. In this case, the event is the receipt of data by the server (req.on).
  // 2. EventEmitter provides multiple properties like on and emit. on property is used to bind a function with the event and emit is used to fire an event. on(event, listener): Adds a listener at the end of the listeners array for the specified event. No checks are made to see if the listener has already been added. Multiple calls passing the same combination of event and listener will result in the listener being added multiple times. Returns emitter, so calls can be chained. https://www.tutorialspoint.com/nodejs/nodejs_event_emitter.htm. In code above, the event is data. Everytime there is a new connection , this server raises a new event to handle that event
  // 3. When an HTTP request hits the server, node calls the request handler function with a few handy objects for dealing with the transaction, request and response. 
  // The request object is an instance of IncomingMessage. SINCE REQUEST OBJECT IS A READABLE STREAM, IT'S ALSO AN EVENTEMITTER; has capabilities of event emitter (http.Server class in http module inherits from net.Server)
  // The response object is an instance of ServerResponse, which is a WRITABLESTREAM. It contains many useful methods for sending data back to the client. 
  // https://nodejs.org/es/docs/guides/anatomy-of-an-http-transaction/
  // 4. REQUEST (req) BODY: When receiving a POST or PUT request, the request body might be important to your application. Getting at the body data is a little more involved than accessing request headers. The request object that's passed in to a handler implements the ReadableStream interface. This stream can be listened to or piped elsewhere just like any other stream. We can grab the data right out of the stream by listening to the stream's 'data' and 'end' events.
  // The chunk emitted in each 'data' event is a Buffer. If you know it's going to be string data, the best thing to do is collect the data in an array, then at the 'end', concatenate and stringify it. https://nodejs.org/es/docs/guides/anatomy-of-an-http-transaction/


// Start our server

server.listen(PORT, function() {
  console.log("Server listening on: http://localhost:" + PORT);
});

// REVIEW OF CONCEPTS:
// req: request object; res: response object
// 1. Before listening, we must REGISTER a listener or handler (see req.on)
// 2. In order to actually serve requests (RUN THE WEB SERVER), the listen method needs to be called on the server object; and listen on a PORT.
// 3. callback function is second parameter to .listen()
// 4. From Node.js, class: http.Server, which inherits from net.Server, with event: 'request", which includes 
// a. request <http.IncomingMessage>
// b. response <http.ServerResponse>
// This 'request' event is emitted each time there is a request. There may be multiple requests per connection.


// REVIEW OF CONCEPTS 
// TEST CODE ABOVE (ensure in same directory as server.js and have terminated prior port from listening for client requests (CTRL+C))
// (using nodemon in terminal): type following in terminal:
// nodemon server.js 
// RETURNS:
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server.js`
// Server listening on: http://localhost:8080
// When we make any changes (e.g., save the server.js document and/or submit a GET or POST request, the following appears on the terminal: 
// ([nodemon] restarting due to changes...
// [nodemon] starting `node server.js`
// 
// TESTING: RUNNING HTTPS REQUEST VIA POSTMAN:
// References: https://www.youtube.com/watch?v=t5n07Ybz7yI, 
// 1. Postman is a tool for working with APIs. If doing server-side coding and want to test code 
// 2. HOW TO USE, DETAILS OF REQUEST
// a. Select what method you want to test: GET and POST are most popular
// b. Enter req.url in address bar/url bar === url you will be sending [SEND] to do a fetch request (can optionally specify a query string) in the address bar. Other options below address bar: 
// 2b1. [Params] enter key-value pairs (what is in the query string)
// 2b2. [Headers] and enter key (e.g., Content Type) and value (e.g., application/json )
// 2b3. [Body] and select raw with JSON (application/json), where the latter is the content type that will be sent (must have double quotation marks around keys)
// 3. REQUEST, Body, POST
  // a. Body is what you're posting to the server, the body of the request
  // b. format options to select: 1) form-data (enter key-value pairs); 2) x-www.form-urlencoded; 3) raw; 4) binary (upload file to test)
  // c. SELECT entries you want to send to send to server to test via (GET, POST)
// 4. REQUEST, Body, GET
  // a. Enter url, query string (ENTER [Params]: key-value pairs (what is in the query string); 
  // b. EXAMPLE: GET->Params (Key: userID; Value: 78) translates into the following URL in address bar, where params represents the query string: http://jsonplaceholder.typicode.com/posts?userid=78 (e.g., response will be all posts by userid=78). NOTE: key-value pairs ARE CASE-SENSITIVE
  // A query string is the portion of a URL where data is passed to a web application and/or back-end database. The reason we need query strings is that the HTTP protocol is stateless by design. For a website to be anything more than a brochure, you need to maintain state (store data). There are a number of ways to do this: On most web servers, you can use something like session state server-side. On the client, you can store via cookies. Or in the URL, you can store data via a query string. https://www.techopedia.com/definition/1228/query-string For example, in the URL below, the bolded area is the query string that was generated when the term "database" was searched on the Techopedia website.
  //www.techopedia.com/search.aspx?q=database§ion=all
  // b. SEE ACTIVITY 01-FirstServer for components of URL 
    
// 5. DETAILS OF RESPONSE, Body
// a. Pretty: allows you to collapse code
// b. Raw: 
// c. Response Headers (similar to what you would see with Google Inspect Tools, Activity 03-Portfolio)
// d. Content Type drop-down menu: JSON, XML, HTML, Text, Auto
// e. "Headers Featured at top right with Pretty: 1) STATUS (e.g., 200 OK); 2) Time (e.g., 137 ms); 3) Size: 6.03 KB

// TESTING ON POSTMAN with post.
// 1. Selecting POST -> url address: http://localhost:8080 -> Body -> raw -> Body content box: St. Louis Blues won the Stanley Cup! === requestData
// RETURNS following in terminal/console/bash:
// You did a POST with the data:
//  St. Louis Blues won the Stanley Cup!
// // 2. Selecting POST -> url address: http://localhost:8080 -> Body -> raw -> JSON(application/json) Body content box: var dog = {
// 	"name": "Snoopy",
// 	"bestFriend": "CharlieBrown"
// }=== requestData
// RETURNS following in terminal/console/bash:
// You did a POST with the data:
//  var dog = {
//         "name": "Snoopy",
//         "bestFriend": "CharlieBrown"
// }
// 3. Testing with the same entry above #2 (SNOOPY), and passing requestData into res.end === res.end(requestData), the same data posted appears in the Response (Body, pretty)

// IF YOU SAVE server.js file, the following lines appear after the requests:
// [nodemon] restarting due to changes...
// [nodemon] starting `node server.js`
// Server listening on: http://localhost:8080