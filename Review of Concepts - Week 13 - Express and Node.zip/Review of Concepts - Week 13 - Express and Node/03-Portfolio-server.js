var http = require("http");

var PORT = 8080;

var server = http.createServer(handleRequest);

// Start our server
server.listen(PORT, function() {
  // Callback triggered when server is successfully listening. Hurray!
  console.log("Server listening on: http://localhost:" + PORT);
});

// REVIEW OF CONCEPTS (RESPONSE OBJECT)
// 1. Same concepts as in 01-FirstServer & 02-Two-Servers

// Create a function which handles incoming requests and sends responses
function handleRequest(req, res) {
  // Capture the url the request is made to
  var path = req.url;

  // Depending on the URL, display a different HTML file.
  switch (path) {

  case "/":
    return displayRoot(path, req, res);

  case "/portfolio":
    return displayPortfolio(path, req, res);

  default:
    return display404(path, req, res);
  }
}
// REVIEW OF CONCEPTS, SWITCH STATEMENT
// 1. Javascript RETURN statement stops the execution of a function and returns a value from that function. 
// 2. Javascript SWITCH statement: a) switch expression is evaluated once; b) value of expression is compared with values of each case. If there is a match, the associated block of code is executed.
// Syntax:
// switch(expression){
// case: x: 
  // code block
  // break;
// case: y: 
  // code block
  // break;
// case: z: 
  // code block
  // break;
// }
// 3. break keyword: cause switch statement to "break out" of the switch statement and continue to next block of code. Without the break statement, additional blocks of code may be executed if the evaluation matches the case value.
// 4. switch statement is an alternate to multiple if..else statements

// When someone visits the "http://localhost:8080/" path, this function is run.
function displayRoot(url, req, res) {
  var myHTML = "<html>" +
    "<body><h1>Home Page</h1>" +
    "<a href='/portfolio'>Portfolio</a>" +
    "</body></html>";

  // Configure the response to return a status code of 200 (meaning everything went OK), and to be an HTML document
  res.writeHead(200, { "Content-Type": "text/html" });

  // End the response by sending the client the myHTML string (which gets rendered as an HTML document thanks to the code above)
  res.end(myHTML);
}

// REVIEW OF CONCEPTS:
// 1. forward slashes (/) in URLs
// a. separate protocol (scheme) part and host (authority) part;
// b. separate path segments;
// c. begin a path.
// 2. set status and headers before writing chunks of data to the RESPONSE body. This makes sense, since headers come before the body in HTTP responses.
// 3. Explicitly Sending Header Data: 
// The methods of setting the headers and status code that we've already discussed assume that you're using "implicit headers". This means you're counting on node to send the headers for you at the correct time before you start sending body data.
// If you want, you can explicitly write the headers to the response stream. To do this, there's a method called writeHead, which writes the status code and the headers to the stream.
// res.writeHead(200, { "Content-Type": "text/html" });
// Once you've set the headers (either implicitly or explicitly), you're ready to start sending response data (sending response body)
// SENDING RESPONSE BODY:
// Since the response object is a WritableStream, writing a response body out to the client is just a matter of using the usual stream methods. The end function on streams can also take in some optional data to send as the last bit of data on the stream, so we can simplify the example above as follows. 
// response.end('<html><body><h1>Hello, World!</h1></body></html>');
// 4. in node.js documentation for http, response.end signals to the server that all of response headers & body have been sent so server should consider this message complete.
// 5. response.end (res.end) MUST be called on each response.

// When someone visits the "http://localhost:8080/portfolio" path, this function is run.
function displayPortfolio(url, req, res) {
  var myHTML = "<html>" +
    "<body><h1>My Portfolio</h1>" +
    "<a href='/'>Go Home</a>" +
    "</body></html>";

  // Configure the response to return a status code of 200 (meaning everything went OK), and to be an HTML document
  res.writeHead(200, { "Content-Type": "text/html" });

  // End the response by sending the client the myHTML string (which gets rendered as an HTML document thanks to the code above)
  res.end(myHTML);
}

// When someone visits any path that is not specifically defined, this function is run.
function display404(url, req, res) {
  var myHTML = "<html>" +
    "<body><h1>404 Not Found </h1>" +
    "<p>The page you were looking for: " + url + " can not be found</p>" +
    "</body></html>";

  // Configure the response to return a status code of 404 (meaning the page/resource asked for couldn't be found), and to be an HTML document
  res.writeHead(404, { "Content-Type": "text/html" });

  // End the response by sending the client the myHTML string (which gets rendered as an HTML document thanks to the code above)
  res.end(myHTML);
}
// REVIEW OF CONCEPTS
// 1. http status 400 means it's a bad request (36:00, https://www.youtube.com/watch?v=L72fhGm1tfE)
// 2. HTTP Status Code: If you don't bother setting it, the HTTP status code on a response will always be 200. Of course, not every HTTP response warrants this, and at some point you'll definitely want to send a different status code. To do that, you can set the statusCode property:
// response.statusCode = 404; // Tell the client that the resource wasn't found. https://nodejs.org/es/docs/guides/anatomy-of-an-http-transaction/


// REVIEW OF CONCEPTS (RESPONSE OBJECT)
// 1. Same concepts as in 01-FirstServer & 02-Two-Servers
// TEST CODE ABOVE (ensure in same directory as server.js)
// 1. Entering the following into terminal/bash: node server.js
// the following RETURNS to the console without entering any url in address bar of browser: Server listening on: http://localhost:8080 (server must be listening 1st on a port to run client requests)
// 2. Entering the following into the address/URL bar of the browser: http://localhost:8080 renders/displays the following HTML on the webpage per displayRoot function (RESPONSE):
// Home Page
// Portfolio
// 3. To see the status and headers (written before response.body or response is sent to client), in chrome: 1) right click to get to Google Dev Tools, Inspect; 2)select Network tab; 3) reload the page; 4) select a)http request on left panel; and b) All to left of XHR; and the following displays under "Headers, General": 
// Request URL: http://localhost:8080/: 
// Request Method: GET
// Status Code: 200 OK
// Remote Address: [::1]:8080
// Referrer Policy: no-referrer-when-downgrade
// The following displays under "Headers, Response Headers":
// Connection: keep-alive
// Content-Type: text/html
// Date: Sun, 16 Jun 2019 23:07:28 GMT
// Transfer-Encoding: chunked
// 4. Since we have yet to terminate the port from which the server listens for a client request (request.url submission), we can enter a new request.url in address/URL bar, with "Server listening on: http://localhost:8080" still appearing on terminal/bash console. This console.log will not duplicate even after entering a new request.url submission since we have not entered code to stop server from listening.
// 5. Entering the following in the address/URL bar: http://localhost:8080/portfolio renders/displays the following HTML on the webpage per displayPortfolio function (RESPONSE):
// My Portfolio
// Go Home
// 6. Since we have yet to terminate the port from which the server listens for a client request (request.url submission), we can enter a new request.url in address/URL bar, with "Server listening on: http://localhost:8080" still appearing on terminal/bash console. 
// 5. Entering the following in the address/URL bar: http://localhost:8080/about renders/displays the following HTML on the webpage per display404 function (RESPONSE):
// 404 Not Found
// The page you were looking for: /about can not be found
// 6. Terminate ports from listening for client requests (CTRL+C)




