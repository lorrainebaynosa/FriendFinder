// Require/import the HTTP module
var http = require("http");
// REVIEW OF CONCEPTS: "http module" is internal to node so DO NOT have to install it. Node.js's HTTP API
// is very low-level, dealing only with steream handling & message parsing (parsing a message into headers & body (H&B) without parsing H&B)

// Define a port to listen for incoming requests
var PORT = 8080;
// REVIEW OF CONCEPTS: 
// 1. 8080 is local host
// 2. If you type "localhost:8080" as a URL now, website displays CANNOT GET/, where / === homepage when dealing with routes; if you type in "localhostport8080/about" as a URL, website displays CANNOT GET/about [route] because no routes have been set up 

// Create a generic function to handle requests and responses
function handleRequest(req, res) {
  // Send the below string to the client when the user visits the PORT URL
  res.end("It Works!! Path Hit: " + req.url);
}
// REVIEW OF CONCEPTS:
// 1. function handleRequest comes from node.js and we won't be using it that much
// 2. response comes from node.js; .end is method from node.js
// 3. req === request, res === response
// 4. in node.js documentation for http, response.end signals to the server that all of response headers & body have been sent so server should consider this message complete.
// response.end (res.end) MUST be called on each response.


// Use the Node HTTP package to create our server.
// Pass the handleRequest function to empower it with functionality.

var server = http.createServer(handleRequest);
// REVIEW OF CONCEPTS:
// 1. http is an object, on which we use method "createServer", which comes from "http"
// 2. passing in function handleRequest and storing http.createServer(handleRequest) in var server
// 3. will only pass in request & response associated with function handleRequest(request, response){} after server begins listening at port 8080
// 4. as soon as code hits server.listen(PORT, function(){}, any requests will implicitly be handled by function handleRequest(response,response){}

// Start our server so that it can begin listening to client requests.
server.listen(PORT, function() {
  // Log (server-side) when our server has started
  console.log("Server listening on: http://localhost:" + PORT);
});

// REVIEW OF CONCEPTS 
// 1. Listen at port 8080 and then run call-back function
// 2. TEST CODE ABOVE:
// 3. Since server is listening at port 8080 (server.listen(PORT, function() {)), when you type it  If you type in "http://localhost:8080" as a URL now, 
// a. terminal console displays "Server listening on: http://localhost:" + PORT 
// b. webpage displays, "It Works!! Path Hit: (response.end("It Works!! Path Hit: " + request.url)), where request.url IS NOT entire url but just path: / in this case
// if we enter "localhost:8080/meow", request.url is now: /meow
// path is syntax for node.js
// 4. URL (Uniform Resource Locator) structure, five (5) parts: 
// a. scheme: tells web serves which protocol to use when accessing page on website; HTTPS: Hypertest Transfer Protocol Secure is most common (encrypts passwords & credit card info)
// b. subdomain: indicates what particular page of your website web browser should serve (blog, offers, other main content categories)
// c. second-level domain: name of your website (e.g., mlb.comm)
// d. top-level domain: type of entity your organization registers as on internet (.com, .edu: commercial and educational entities in US, )
// e. subdirectory: helps people understand which section of webpage they're on.
// 5. components of URL:
// a. scheme
// b. host name/domain name: identifies host that holds the resource (e.g., example.com). Host names can also be followed by a port number, the latter of which is sometimes omitted.
// c. path: specific resource in host that web client wants to access (e.g., /software/htp/cics/index.html)
// d. query string: usualy a string of name & value pairs. Name/value pairs are separated from each other by and an ampersand: scheme://host:port/path?query

// TEST CODE ABOVE (ensure in same directory as server.js)
// 1. Since http is part of Node.js, we don't have to run a npm package.
// 2. On terminal type: node server.js:
// a. console log: RETURNS: Server listening on: http://localhost:8080
// NOTE: THIS CONSOLE LOG WILL DISPLAY BEFORE TYPING IN REQ.URL in address bar (server must be listening first)
// b. typing the following in address bar of webpage: http://localhost:8080/ renders the following on the webpage: It Works!! Path Hit: /
// 3. forward slashes (/) in URLs
// a. separate protocol (scheme) part and host (authority) part;
// b. separate path segments;
// c. begin a path.
// 4. Without resetting/restarting server (message on console remains), if we type in http://localhost:8080/aboutme in address bar renders following on webpage: It Works!! Path Hit: /aboutme 
// a. about me === path ==== req.url

