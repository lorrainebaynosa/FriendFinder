// can test with nodemon vs node on terminal

// * Work with those around you to confirm your `server1.js` file is working. This means figuring out: what dependencies to install, how to run the file, and how to view the resulting website in your browser. This step requires you to make ZERO changes to the code file. At this point, you are just getting the file you are given to run.
//   * Then, once you've gotten the original code to display in the browser, create a new `Obi Wan Kenobi route` to display Kenobi's information. Use the comments and the previous code in the file as a guide.


// Dependencies
// ===========================================================
var express = require("express");

var app = express();
var PORT = 3000;

// REVIEW OF CONCEPTS
// 1. express framework is built on top of http module in node
// 2. In order to use express, we'll need to have it listed as a dependency (package.json) and install it. If it's already listed as a dependency, just run npm install.
// 3. Documentation for express npm module per https://www.npmjs.com/package/express    
// const express = require('express')
// const app = express()
 
// app.get('/', function (req, res) {
//   res.send('Hello World')
// })
 
// app.listen(3000)

// Data
// ===========================================================
var yoda = {
  name: "Yoda",
  role: "Jedi Master",
  age: 900,
  forcePoints: 2000
};

var darthmaul = {
  name: "Darth Maul",
  role: "Sith Lord",
  age: 200,
  forcePoints: 1200
};
// REVIEW OF CONCEPTS:
// 1. yoda and darthmaul are objects with properties of name, role, age, and forcePoints; will use objects to retrieve JSON data

// Create one more data entry for the character Obi Wan Kenobi.
// Enter any values you like for the parameters following the same format as the Yoda and Darth Maul character

var ObiWanKenobi = {
  name: "Obi Wan Kenobi",
  role: "I don't know",
  age: 300,
  forcePoints: 1500
};

// REVIEW OF CONCEPTS; 
// 1. Follow same format for yoda & darthmaul to create an object



// Routes, Controller === CREATING AN API

//   * Then, once you've gotten the original code to display in the browser, create a new `Obi Wan Kenobi route` to display Kenobi's information. Use the comments and the previous code in the file as a guide.
// ===========================================================
app.get("/", function(req, res) {
  res.send("Welcome to the Star Wars Page!");
});

// ROC (below): res.json sends back JSON data
app.get("/yoda", function(req, res) {
  res.json(yoda);
});

app.get("/darthmaul", function(req, res) {
  res.json(darthmaul);
});
// Create a new Express route that leads users to the new Obi Wan Kenobi Data
// Follow the same format as the Yoda and Darth Maul routes
app.get("/ObiWanKenobi", function(req, res) {
  res.json(ObiWanKenobi);
});

// REVIEW OF CONCEPTS:
// 1. Documentation for express npm module per https://www.npmjs.com/package/express    
// const express = require('express')
// const app = express()
 
// app.get('/', function (req, res) {
//   res.send('Hello World')
// })
 
// app.listen(3000)
// 2. when you go to a webpage, you are implicitly sending a GET request
// .get = http method ; 
// "/" === route
// 3. https://blog.fullstacktraining.com/res-json-vs-res-send-vs-res-end-in-express/
// Sending a response can be achieved by calling the res.send() method. The signature of this method looks like this: res.send([body]) where the body can be any of the following: Buffer, String, an Object and an Array.
// res.json(), Express sets 'Content-Type' to application/json; res.json() actually has some functionality that is related to JSON objects that we can't access when using res.send(). Namely, it can format the returned JSON data by applying two options: These two options are collected and passed to the JSON.stringify() method: since its signature looks like this: JSON.stringify(object, replacer, space ). Once this method is called, the res.json() method will then call res.send() as well under the hood.

// Listener
// ===========================================================
app.listen(PORT, function() {
  console.log("App listening on PORT " + PORT);
});

// REVIEW OF CONCEPTS, 
// 1. EXPRESS is a Node.js npm module that is not case-sensitive; Fast, unopinionated, minimalist web framework for node; provides a robust set of features for web and mobile applications; with a myriad of HTTP utility methods and middleware at your disposal, creating a robust API is quick and easy; provides a thin layer of fundamental web application features, without obscuring Node.js features. https://expressjs.com/

// TESTING THE CODE ABOVE VIA BROWSER:
// 1. Since express is already listed as a dependency in package.json, run npm install express.
// 2. Ensure you are in the root directory of app you are testing.
// 3. In terminal/node/bash, ENTER: nodemon server1.js
// RETURNS: [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server1.js`
// App listening on PORT 3000
// 4. In browser url/address bar ENTER: http://localhost:3000/
// RETURNS: Welcome to the Star Wars Page!
// 5. entering following in URL/address bar of Chrome browswer: http://localhost:3000/ObiWanKenobi
// RETURNS JSON DATA on webpage: 
// {
// "name": "Obi Wan Kenobi",
// "role": "I don't know",
// "age": 300,
// "forcePoints": 1500
// }
// 6. If any changes are made to server1.js, this will appear in the terminal: 
// [nodemon] restarting due to changes...
// [nodemon] starting `node server1.js`
// App listening on PORT 3000
// 7. ENTER CTRL+C on terminal/bash to stop app from listening on PORT 3000

// TESTING CODE WITH POSTMAN
// GET request; ENTER into URL/address bar: http://localhost:3000/yoda
// Body->raw->JSON(application/json)
// Body content box, REQUEST, OPTION 1: 
// var yoda = {
//   "name": "Yoda",
//   "role": "Jedi Master",
//   "age": 900,
//   "forcePoints": 2000
// };
// OR
// Body content box, REQUEST, OPTION 2: 
// var yoda = {
//   name: "Yoda",
//   role: "Jedi Master",
//   age: 900,
//   forcePoints: 2000
// };
// SEND 
// RETURNS: 
// {
//   "name": "Yoda",
//   "role": "Jedi Master",
//   "age": 900,
//   "forcePoints": 2000
// }