// Dependencies
// ===========================================================
var express = require("express");

var app = express();
var PORT = 3000;

// Data
// ===========================================================
var characters = [{
  routeName: "yoda",
  name: "Yoda",
  role: "Jedi Master",
  age: 900,
  forcePoints: 2000
}, {
  routeName: "darthmaul",
  name: "Darth Maul",
  role: "Sith Lord",
  age: 200,
  forcePoints: 1200
}, {
  routeName: "obiwankenobi",
  name: "Obi Wan Kenobi",
  role: "Jedi Master",
  age: 55,
  forcePoints: 1350
}];

// Routes
// ===========================================================

app.get("/", function(req, res) {
  res.send("Welcome to the Star Wars Page!");
});

// What does this route do? (below)
app.get("/api/characters", function(req, res) {
  return res.json(characters);
});


// What does this route do?
app.get("/api/characters/:character", function(req, res) {
  // What does this code do?
  var chosen = req.params.character;
  console.log(chosen);

  // What does this code do?
  for (var i = 0; i < characters.length; i++) {
    if (chosen === characters[i].routeName) {
      return res.json(characters[i]);
    }
  }

  // What does this code do?
  return res.send("No character found");
});

// Listener
// ===========================================================
app.listen(PORT, function() {
  console.log("App listening on PORT " + PORT);
});

// REVIEW OF CONCEPTS (testing code above)
// 1. "return" prevents execution of further code
// 2. Since express is already listed as a dependency in package.json, run npm install express.
// 3. Ensure you are in the root directory of app you are testing.
// 4. In terminal/node/bash, ENTER: nodemon server3.js
// RETURNS: 
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server2.js`
// App listening on PORT 3000
// 5. In browser url/address bar ENTER: http://localhost:3000/
// RETURNS: Welcome to the Star Wars Page!
// 6. entering following in URL/address bar of Chrome browswer: http://localhost:3000/api/characters
// RETURNS:
// [
// {
//   "routeName": "yoda",
//   "name": "Yoda",
//   "role": "Jedi Master",
//   "age": 900,
//   "forcePoints": 2000
//   },
//   {
//   "routeName": "darthmaul",
//   "name": "Darth Maul",
//   "role": "Sith Lord",
//   "age": 200,
//   "forcePoints": 1200
//   },
//   {
//   "routeName": "obiwankenobi",
//   "name": "Obi Wan Kenobi",
//   "role": "Jedi Master",
//   "age": 55,
//   "forcePoints": 1350
//   }
//   ]
// 7. Testing a different route to get the character object with all its properties (key/value pairs): entering following in URL/address bar of Chrome browswer: http://localhost:3000/api/characters/yoda
// RETURNS:
// 1. on the terminal/bash/console: yoda 
// 2. renders on the Chrome webpage: 
// {
// "routeName": "yoda",
// "name": "Yoda",
// "role": "Jedi Master",
// "age": 900,
// "forcePoints": 2000
// }
// 8. Testing a different route with a character NOT in the array of characters: entering following in URL/address bar of Chrome browswer: http://localhost:3000/api/characters/princessLeah
// RETURNS:
// 1. on the terminal/bash/console: princessLeah
// 2. renders on the Chrome webpage: No character found