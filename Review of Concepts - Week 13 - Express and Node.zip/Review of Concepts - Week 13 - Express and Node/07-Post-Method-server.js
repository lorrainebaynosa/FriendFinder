// Create an HTML file with a form that will post data.
// * Create a server that will accept the POSTed data and log it to the console.

// REVIEW OF CONCEPTS:
// 1. fs is a core Node package for reading and writing files
// 2. http is part of node

// Dependencies
var http = require("http");
var fs = require("fs");

var PORT = 8080;

var server = http.createServer(handleRequest);

function handleRequest(req, res) {
  var path = req.url;

  switch (path) {
  case "/thanks":
    return renderThankYouPage(req, res);
  default:
    return renderWelcomePage(req, res);
  }
}
// REVIEW OF CONCEPTS 
// 1. createServer method, part of Node.js, creates 1) a server on your computer (turns your computer into a HTTP server); 2) create a HTTP Server object that can listen to ports on your computer AND execute a function, a requestListener, each time a request is made. 
// var http = require('http');
// http.createServer(function (req, res) {
  // res.writeHead(200, {'Content-type': 'text/plain'});
  // res.write('Hellow World!');
  // res.end();
// }).listen(8080);

// 2. SWITCH STATEMENT in javascript is used to select one of many code blocks to be executed. Switch expression is evaluated once. Value of each expression is compared with values of each case. If there is a match, the associated block of code is executed. When JavaScript reaches a BREAK keyword, it breaks out of the switch block, which will stop execution of inside the block. It is not necesary to break the last case in a switch block as the block ends there anyways. The DEFAULT keyword specifies the code to run if there is no case match; and DOES NOT have to be the last case in a switch block but if not, it must be ended with a break.The Syntax:
// switch (expression) {
// case x: 
  // code block
  // break;
// case y: 
  // code block
  // break;
// default:
  // code block
// }
function renderWelcomePage(req, res) {
  fs.readFile(__dirname + "/index.html", function(err, data) {
    if (err) {
      res.writeHead(500, { "Content-Type": "text/html" });
      res.end("<html><head><title>Oops</title></head><body><h1>Oops, there was an error</h1></html>");
    }
    else {
      // We then respond to the client with the HTML page by specifically telling the browser that we are delivering an html file.
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(data);
    }
  });
}
// REVIEW OF CONCEPTS:
// 1. fs.readFile(path[, options], callback), where path is the filename (string), callback function (err, data): means this code ASYNCHRONOUSLY reads entire contents of a file, where data is the contents fo the file. When the path is a directory, 
// 2. By checking the URL in this way, we're doing a form of "routing". Other forms of routing can be as simple as switch statements or as complex as whole frameworks like express. 
// https://nodejs.org/es/docs/guides/anatomy-of-an-http-transaction/

function renderThankYouPage(req, res) {
  // Saving the request posted data as a variable.
  var requestData = "";

  var myHTML =
    "<html><head><title>Hello Noder!</title></head><body><h1>Oops, I didn't get any data</h1></body></html>";

  // When the server receives data, it will add it to requestData.
  req.on("data", function(data) {
    requestData += data;
    console.log("You just posted some data to the server:\n", requestData);

    myHTML =
      "<html><head><title>Hello Noder!</title></head><body>" +
      "<h1>Thank you for the data: </h1><code>" +
      requestData +
      "</code>" +
      "</body></html>";
  });

  // When the request has ended...
  req.on("end", function() {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(myHTML);
  });
}

// Starts our server.

server.listen(PORT, function() {
  console.log("Server listening on: http://localhost:" + PORT);
});
// REVIEW OF CONCEPTS: 
// 1. HTTP server method listen() makes the server listen to ports on the computer.
// 2. Same concepts as 06-Requests-Methods except that we're using a switch statement to determine whether to readFile and passing

// TEST CODE ABOVE (ensure in same directory as server.js and have terminated prior port from listening for client requests (CTRL+C))
// 1. (using nodemon in terminal): type following in terminal: nodemon server.js 
// 2. In POSTMAN: Selecting POST -> url address: http://localhost:8080/thanks -> Body -> raw -> Text(text/plain) -> Body content box: thanks for using Postman === requestData
// a. RETURNS following in terminal/console/bash:
// You just posted some data to the server:
//  thanks for using Postman
// b. RETURNS following in Postman, RESPONSE Content Box (Body, Pretty) because we've passed myHTML into res.end: 
// {/* <html>
//     <head>
//         <title>Hello Noder!</title>
//     </head>
//     <body>
//         <h1>Thank you for the data: </h1>
//         <code>thanks for using Postman</code>
//     </body>
// </html> */}

// TEST CODE ABOVE USING POSTMAN (ensure in same directory as server.js and have terminated prior port from listening for client requests (CTRL+C))
// 1. (using nodemon in terminal): type following in terminal: nodemon server.js 
// 2. In POSTMAN: Selecting POST -> url address: http://localhost:8080/ -> Body -> raw -> Text(text/plain) -> Body content box: Toronto Raptors win the NBA Championship === requestData
// a. RETURNS following in terminal/console/bash: NOTHING because there is no code to console.log anything
// b. RETURNS following in Postman, RESPONSE Content Box (Body, Pretty) because we've passed data into res.end [res.end(data)] when renderWelcomePage with url request

// TEST CODE ABOVE USING BROWSER (ensure in same directory as server.js)
// EXECUTING SWITCH STATEMENT - DEFAULT CASE
// 1. Still in same directory and using nodemon to listen on localhost:8080,
// 2. Enter the following in the url/address browser in Chrome browser: http://localhost:8080/, the Simple Form is rendered on the page per function renderWelcomePage as the data (index.html file) is passed into res.end [res.end(data);]
// 3. NOTHING is logged to terminal/console/bash because our code doesn't dictate this.

// EXECUTING SWITCH STATEMENT - case "/thanks":
// 1. Still in same directory and using nodemon to listen on localhost:8080, we'll call function renderThankYouPage by entering the following in the address/url bar and executing switch statement with path "/thanks"
// 2. Enter the following in the url/address browser in Chrome browser: http://localhost:8080/thanks, the following is rendered onto the browser page: Oops, I didn't get any data because we've passed myHTML into res.end [res.end(myHTML);]. Compare this to execution on POSTMAN where we actually post data.
// 3. NOTHING is logged to terminal/console/bash because our code doesn't dictate this (NOTHING WAS POSTED - we just specified a path). Compare this to execution on POSTMAN where we actually post data.

