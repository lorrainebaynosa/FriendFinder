// Dependencies
var express = require("express");

var app = express();
var PORT = 3000;

// Sets up the Express app to handle data parsing 
// REVIEW OF CONCEPTS: MIDDLEWARE
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Data
var characters = [
  {
    routeName: "yoda",
    name: "Yoda",
    role: "Jedi Master",
    age: 900,
    forcePoints: 2000
  },
  {
    routeName: "darthmaul",
    name: "Darth Maul",
    role: "Sith Lord",
    age: 200,
    forcePoints: 1200
  },
  {
    routeName: "obiwankenobi",
    name: "Obi Wan Kenobi",
    role: "Jedi Master",
    age: 55,
    forcePoints: 1350
  }
];

// Routes
app.get("/", function(req, res) {
  res.send("Welcome to the Star Wars Page!");
});

// Displays all characters
app.get("/api/characters", function(req, res) {
  return res.json(characters);
});

// Displays a single character, or shows "No character found"
app.get("/api/characters/:character", function(req, res) {
  var chosen = req.params.character;

  console.log(chosen);

  for (var i = 0; i < characters.length; i++) {
    if (chosen === characters[i].routeName) {
      return res.json(characters[i]);
    }
  }

  return res.send("No character found");

});

// Create New Characters - takes in JSON input
app.post("/api/characters", function(req, res) {
  var newcharacter = req.body;

  console.log(newcharacter);

  characters.push(newcharacter);

  // res.json(newcharacter);
  res.json(characters);
});

app.listen(PORT, function() {
  console.log("App listening on PORT " + PORT);
});

// REVIEW OF CONCEPTS: 
// 1. Parsing means to make something understandable (by analysing its parts)
// 2. middleware, in express, acts on data before it gets processed by server. In express, .use is a method that acts as middleware. app.use middleware checks if data is urlencoded or .json and stores it into req.body
// app.post("/api/characters", function(req, res) {}: If making request to express server, before it gets to any route, going to place information in request.body (req.body)
// 3. Exact same codes as in Activity10 & 11 except for post request (app.post)

// TESTING CODE ABOVE USING TERMINAL & POSTMAN
// 1. Since express is already listed as a dependency in package.json, run npm install express.
// 2. Ensure you are in the root directory of app you are testing.
// 3. In terminal/node/bash, ENTER: nodemon server5.js
// RETURNS: 
// [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server2.js`
// App listening on PORT 3000
// 4. POSTMAN: Select POST method
// 5. POSTMAN: ENTER in URL/address bar of Postman browswer: http://localhost:3000/api/characters
// 6. POSTMAN: Body->raw->JSON (application/json)->Body, Content Box (req.body): 
// {
// 	"routeName": "princessLeah",
//     "name": "Princess Leah",
//     "role": "Princess",
//     "age": 35,
//     "forcePoints": 5000
// }
// RETURNS (on Postman, RESPONSE), JSON data syntax
// {
//   "routeName": "princessLeah",
//   "name": "Princess Leah",
//   "role": "Princess",
//   "age": 35,
//   "forcePoints": 5000
// }
// RETURNS (on terminal): Javascript Object
// { routeName: 'princessLeah',
  // name: 'Princess Leah',
  // role: 'Princess',
  // age: 35,
  // forcePoints: 5000 }
// 7. If we want to see the new array of characters with Princess Leah, we'll need to change the code to show the json for the new characters array: 
// app.post("/api/characters", function(req, res) {
//   var newcharacter = req.body;

//   console.log(newcharacter);

//   characters.push(newcharacter);

//   // res.json(newcharacter);
//   res.json(characters);
// });
// 8. Running the same POST with same url in address/url bar returns the same response on the console but a different response: 
// [
//   {
//       "routeName": "yoda",
//       "name": "Yoda",
//       "role": "Jedi Master",
//       "age": 900,
//       "forcePoints": 2000
//   },
//   {
//       "routeName": "darthmaul",
//       "name": "Darth Maul",
//       "role": "Sith Lord",
//       "age": 200,
//       "forcePoints": 1200
//   },
//   {
//       "routeName": "obiwankenobi",
//       "name": "Obi Wan Kenobi",
//       "role": "Jedi Master",
//       "age": 55,
//       "forcePoints": 1350
//   },
//   {
//       "routeName": "princessLeah",
//       "name": "Princess Leah",
//       "role": "Princess",
//       "age": 35,
//       "forcePoints": 5000
//   }
// ]





