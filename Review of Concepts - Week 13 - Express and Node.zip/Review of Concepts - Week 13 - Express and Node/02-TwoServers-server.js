// We require/import the HTTP module
var http = require("http");

// =====================================================================

// Then define the ports we want to listen to
var PORTONE = 7000;
var PORTTWO = 7500;

// =====================================================================

// We need two different functions to handle requests, one for each server.
function handleRequestOne(request, response) {
  response.end("To err is human, but to really foul things up you need a computer.");
}

function handleRequestTwo(request, response) {
  response.end("Never trust a computer you can't throw out a window.");
}

// =====================================================================

// Create our servers
var serverOne = http.createServer(handleRequestOne);
var serverTwo = http.createServer(handleRequestTwo);

// =====================================================================

// Starting our servers
serverOne.listen(PORTONE, function() {

  // Callback triggered when server is successfully listening. Hurray!
  console.log("Server listening on: http://localhost:" + PORTONE);
});

serverTwo.listen(PORTTWO, function() {

  // Callback triggered when server is successfully listening. Hurray!
  console.log("Server listening on: http://localhost:" + PORTTWO);
});

// REVIEW OF CONCEPTS (ensure in same directory as server.js)
// 1. similar concepts to 01-First Server, except we must have (2) different a) ports listening to client requests, b) functions to handle requests to made to each server; c) servers
// TEST CODE ABOVE (ensure in same directory as server.js and have terminated prior port from listening for client requests (CTRL+C)
// 1. Since http is part of Node.js, we don't have to run a npm package.
// 2. TESTING PORTONE: On terminal type: node server.js:
var PORTONE = 7000;
var PORTTWO = 7500;
// a. console log: RETURNS: 
// Server listening on: http://localhost:7000
// Server listening on: http://localhost:7500
// NOTE: THIS CONSOLE LOG WILL DISPLAY BEFORE TYPING IN REQ.URL in address bar (server must be listening first)
// b. typing the following in address bar of webpage: http://localhost:7000 for PORTONE renders the following on the webpage: "To err is human, but to really foul things up you need a computer.""
// whereas typing the following in address bar of webpage (without resetting/restarting server): http://localhost:7500 for PORTWO renders the following on the webpage: "Never trust a computer you can't throw out a window."
// 4. Without resetting/restarting server (message on console remains), if we type in http://localhost:7500/aboutme renders the following on the webpage: "Never trust a computer you can't throw out a window.
// a. about me === path ==== req.url
// 5. Without resetting/restarting server (message on console remains), if we type in http://localhost:7500/about me renders the following on the webpage: "Never trust a computer you can't throw out a window." Web address is url encoded before it get to server (via middleware) so address is converted to: http://localhost:7500/about%20me
// 6. Terminate ports from listening for client requests (CTRL+C)