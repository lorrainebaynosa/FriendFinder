// Dependencies
// ===========================================================
var express = require("express");

var app = express();
var PORT = 3000;

// Data
var characters = [{
  routeName: "yoda",
  name: "Yoda",
  role: "Jedi Master",
  age: 900,
  forcePoints: 2000
}, {
  routeName: "darthmaul",
  name: "Darth Maul",
  role: "Sith Lord",
  age: 200,
  forcePoints: 1200
}, {
  routeName: "obiwankenobi",
  name: "Obi Wan Kenobi",
  role: "Jedi Knight",
  age: 60,
  forcePoints: 1350
}];

// Routes (ROC: similar to creating an API)
// ROC:
// req === request
// res === response
// ===========================================================
app.get("/", function(req, res) {
  res.send("Welcome to the Star Wars Page!");
});

// "/:character", where character can be any name; part of express documentation
app.get("/:character", function(req, res) {
  var chosen = req.params.character;

  // What does this log?
  console.log(chosen);

  // res.end();
  res.end(chosen);
  // where chosen is displayed on webpage; if don't pass in chosen, won't display anything on webpage
});


// Listener
// ===========================================================
app.listen(PORT, function() {
  console.log("App listening on PORT " + PORT);
});

// REVIEW OF CONCEPTS (testing code above)
// 1. Since express is already listed as a dependency in package.json, run npm install express.
// 2. Ensure you are in the root directory of app you are testing.
// 3. In terminal/node/bash, ENTER: nodemon server2.js
// RETURNS: [nodemon] 1.19.1
// [nodemon] to restart at any time, enter `rs`
// [nodemon] watching: *.*
// [nodemon] starting `node server2.js`
// App listening on PORT 3000
// 4. In browser url/address bar ENTER: http://localhost:3000/
// RETURNS: Welcome to the Star Wars Page!
// 5. entering following in URL/address bar of Chrome browswer: http://localhost:3000/darthmaul
// RETURNS: darthmaul (on the terminal/bash/console) and browser if we specify res.end(chosen). If we only run res.end(), "darthmaul" will not render on browser but only on console. 
// We can use res.end() if we want to end the response without providing any data. NOTICE how we received the object darthmaul if we specified res.json(darthmaul), 13-express, ACTIVITY08-StarWars-1
// 6. enter CTRL+C into terminal/bash/console to stop app from listening on port 3000