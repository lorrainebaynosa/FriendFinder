// * Create a website with four routes:
//   * Home
//   * Favorite Foods
//   * Favorite Movies
//   * Favorite CSS Frameworks
// * Each route should be triggered by a different URL.
// * Each route should display an HTML page listing your favorite three things of each.
// * Be sure to use `fs` to serve your HTML files.

// ## Bonuses
// * Have your home page have links to all of your other pages.
// * DRY up your code by only having a single `readFile`

// Require dependencies
var http = require("http");
var fs = require("fs");
// REVIEW OF CONCEPTS:
// 1. http & fs are core modules of Node.js. In order to use them, we need to import them via require() function, the latter of which returns an object, function,or property or any other JavaScript type, depending  on what specified module returns. fs module includes classes, methods, & events to work with file I/O (input/output). NOTE: we do not have to npm init or install these modules because they are core to Node.js 

// Set our port to 8080
var PORT = 8080;

var server = http.createServer(handleRequest);

function handleRequest(req, res) {

  // Capture the url the request is made to
  var path = req.url;

  // When we visit different urls, read and respond with different files
  switch (path) {

  case "/food":
    return fs.readFile(__dirname + "/food.html", function(err, data) {
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(data);
    });

  case "/movies":
    return fs.readFile(__dirname + "/movies.html", function(err, data) {
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(data);
    });

  case "/frameworks":
    return fs.readFile(__dirname + "/frameworks.html", function(err, data) {
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(data);
    });

    // default to rendering index.html, if none of above cases are hit
  default:
    return fs.readFile(__dirname + "/index.html", function(err, data) {
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(data);
    });
  }
}
// REVIEW OF CONCEPTS:
// 1. Syntax:
// switch(expression){
// case: x: 
  // code block
  // break;
// case: y: 
  // code block
  // break;
// case: z: 
  // code block
  // break;
// } 
// 1a. where expression === path
// 1b. Javascript RETURN statement stops the execution of a function and returns a value from that function. 
// 1c. Javascript SWITCH statement: a) switch expression is evaluated once; b) value of expression is compared with values of each case. If there is a match, the associated block of code is executed.
// 1d. break keyword: cause switch statement to "break out" of the switch statement and continue to next block of code. Without the break statement, additional blocks of code may be executed if the evaluation matches the case value.
// 1e. req === request, res === response
// 1f. switch statement is an alternate to multiple if..else statements
// 2. fs.readFile(path[,options], callback)[src]: Asynchronously reads entire contents of file
// path: __dirname + "/food.html"
// callback function: function(err, data) {
//       res.writeHead(200, { "Content-Type": "text/html" });
// 2a. return fs.readFile(__dirname + "/food.html", function(err, data): {callback function function(err, data) (after readFile food.html), where data represents data read from file food.html/contents of file food.html; request is sent in request Object; response is sent in response object. Same concepts apply to reading the other three html files.
  // res.writeHead(200, { "Content-Type": "text/html" }); : Configure the response to return a status code of 200 (meaning everything went OK), and to be an HTML document: see Activity03-Porfolio for header details (status code, content-type)
  // res.end(data): End the response by sending the client the data, which gets rendered as the food.html document:
  
// Starts our server.
server.listen(PORT, function() {
  console.log("Server is listening on PORT: " + PORT);
});

// REVIEW OF CONCEPTS
// TEST CODE ABOVE (ensure in same directory as server.js and have terminated prior port from listening for client requests (CTRL+C))
// 1. enter the following in terminal: node server.js
// 2. RETURNS ON CONSOLE/TERMINAL/BASH: Server is listening on PORT: 8080 (server must be listening before it can process a client request)
// 3. then enter the following into address/URL bar: http://localhost:8080/food (NOTE: the path is /food per switch statement - NOT food.html)
// 4. renders/displays the following on the webpage (food.html file): 
// Foods

// Soylent
// Pizza
// Shrimp tempura
// 5. similarly, entering different paths ("/movies", "/frameworks", path not specified in switch statement displays/renders movies.html, frameworks.html, and index.html to the webpage, respectively per switch statement. While different files are entered into address/URL bar, message on console/bash remains the same as server is still listening.
// 6. Terminate port from listening for client requests (CTRL+C)